import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Shield, 
  X, 
  Terminal, 
  Sparkles, 
  Coins, 
  VolumeX, 
  Zap, 
  Compass, 
  CloudRain, 
  Skull,
  MousePointerClick
} from 'lucide-react';
import { UserData } from '../../types';
import { db } from '../../services/firebase';
import { doc, setDoc } from 'firebase/firestore';

interface AdminConsoleProps {
  isOpen: boolean;
  onClose: () => void;
  userData: UserData;
  updateUserData: (data: Partial<UserData> | ((prev: UserData) => UserData)) => void;
  isOnline: boolean;
  onLocalMangoRain: (durationSec: number) => void;
}

export default function AdminConsole({ 
  isOpen, 
  onClose, 
  userData, 
  updateUserData, 
  isOnline,
  onLocalMangoRain
}: AdminConsoleProps) {
  // Phase 1: Authentication
  const [isAdminUnlocked, setIsAdminUnlocked] = useState(() => {
    return localStorage.getItem('admin_abuse_unlocked') === 'true';
  });
  const [adminCode, setAdminCode] = useState('');
  const [authError, setAuthError] = useState('');
  
  // Phase 2: Active Panel Controls
  const [broadCastText, setBroadCastText] = useState('');
  const [broadcastColor, setBroadcastColor] = useState('#f43f5e'); // red/rose
  const [customBroadcastSender, setCustomBroadcastSender] = useState('ADMIN ABUSE');
  const [actionSuccessMsg, setActionSuccessMsg] = useState('');

  // Multipliers
  const [luckMultiplier, setLuckMultiplier] = useState(5);
  const [luckDuration, setLuckDuration] = useState(60); // 1 minute default (in seconds)
  
  const [coinMultiplier, setCoinMultiplier] = useState(3);
  const [coinDuration, setCoinDuration] = useState(60); // 1 minute (in seconds)

  // Rain
  const [rainDurationChoice, setRainDurationChoice] = useState(30); // 30 seconds default

  // Fun Effects Toggles
  const [rainbowScreen, setRainbowScreen] = useState(false);
  const [isNuked, setIsNuked] = useState(false);

  // Status counters
  const [currentTime, setCurrentTime] = useState(Date.now());

  useEffect(() => {
    const t = setInterval(() => setCurrentTime(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminCode.trim().toLowerCase() === 'camel155') {
      setIsAdminUnlocked(true);
      localStorage.setItem('admin_abuse_unlocked', 'true');
      setAuthError('');
      setAdminCode('');
    } else {
      setAuthError('INVALID ACCESS KEY! TRY AGAIN.');
      setTimeout(() => setAuthError(''), 3000);
    }
  };

  const triggerBroadcast = async (text: string, overrideParams?: any) => {
    if (!text.trim() && !overrideParams) return;

    try {
      const payload: any = {
        message: text.trim(),
        activeUntil: text.trim() ? Date.now() + 10000 : 0, // 10s display
        color: broadcastColor,
        sender: customBroadcastSender,
        ...overrideParams
      };

      // 1. Write globally to Firestore to sync across all clients/tabs immediately
      await setDoc(doc(db, 'admin_broadcast', 'current'), payload, { merge: true });

      // 2. Also register locally in window for immediate feedback if Solo/offline
      (window as any)._onReceiveBroadcast?.(payload);

      setBroadCastText('');
      showTemporarySuccess('Broadcast successful!');
    } catch (e) {
      console.error("Failed to post broadcast", e);
      // Fallback local post if firestore fails
      const fallbackPayload = {
        message: text.trim(),
        activeUntil: text.trim() ? Date.now() + 10000 : 0,
        color: broadcastColor,
        sender: customBroadcastSender,
        ...overrideParams
      };
      (window as any)._onReceiveBroadcast?.(fallbackPayload);
      showTemporarySuccess('Broadcast posted (offline fallback)');
    }
  };

  const startMangoPointsRain = () => {
    const expiryTime = Date.now() + rainDurationChoice * 1000;
    
    // Set locally in parent state
    onLocalMangoRain(rainDurationChoice);

    // Broadcast globally to all players
    triggerBroadcast(`🌧️ [SYSTEM RAIN]: Admin has spawned a ${rainDurationChoice}s MANGO POINTS RAIN! click Mangoes to earn +5!`, { rainActiveUntil: expiryTime });
    showTemporarySuccess('Mango rain started globally!');
  };

  const applyLuckBoost = () => {
    const durationMs = luckDuration * 1000;
    const expiry = Date.now() + durationMs;
    
    updateUserData({
      adminLuckMultiplier: luckMultiplier,
      adminLuckExpr: expiry
    });

    triggerBroadcast(`🔮 [LUCK BOOST]: ${luckMultiplier}X LUCK is active for ${luckDuration}s! Crates unboxing is supercharged!`, {
      luckMultiplier: luckMultiplier,
      luckActiveUntil: expiry
    });
    showTemporarySuccess(`Applied ${luckMultiplier}X Luck multiplier globally!`);
  };

  const applyCoinBoost = () => {
    const durationMs = coinDuration * 1000;
    const expiry = Date.now() + durationMs;

    updateUserData({
      adminCoinMultiplier: coinMultiplier,
      adminCoinExpr: expiry
    });

    triggerBroadcast(`🪙 [COIN MULTIPLIER]: Admin has granted a ${coinMultiplier}X Coin boost for ${coinDuration}s! Finish game to earn mega coins!`, {
      coinMultiplier: coinMultiplier,
      coinActiveUntil: expiry
    });
    showTemporarySuccess(`Applied ${coinMultiplier}X Coin multiplier globally!`);
  };

  const showTemporarySuccess = (msg: string) => {
    setActionSuccessMsg(msg);
    setTimeout(() => setActionSuccessMsg(''), 2500);
  };

  const resetAllModifiers = () => {
    updateUserData({
      adminLuckMultiplier: 1,
      adminLuckExpr: 0,
      adminCoinMultiplier: 1,
      adminCoinExpr: 0
    });
    triggerBroadcast(`⚠️ [SYSTEM RESET]: Admin has terminated all active multipliers.`, {
      luckMultiplier: 1,
      luckActiveUntil: 0,
      coinMultiplier: 1,
      coinActiveUntil: 0,
      rainActiveUntil: 0,
      nukedAt: 0
    });
    showTemporarySuccess('Terminated all active multipliers globally.');
  };

  // Fun simulated action: SLAP ALL players (Roblox style!)
  const triggerSlapAll = () => {
    const timestamp = Date.now();
    triggerBroadcast(`👋 [SLAP ALL]: Admin has SLAPPED everyone in the arena! OOF!`, {
      slappedAt: timestamp
    });
    showTemporarySuccess('Played Slap command globally!');
  };

  // Fun simulated action: NUKE the server (Roblox style!)
  const triggerNuke = () => {
    setIsNuked(true);
    const timestamp = Date.now();
    triggerBroadcast(`☢️ [SERVER NUKE]: 10 SECONDS UNTIL SERVER DESTRUCTION!`, {
      nukedAt: timestamp
    });
    setTimeout(() => {
      setIsNuked(false);
    }, 10000);
    showTemporarySuccess('Nuke simulation count started globally!');
  };

  const lockAdminConsole = () => {
    setIsAdminUnlocked(false);
    localStorage.removeItem('admin_abuse_unlocked');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[180] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className={`w-full max-w-2xl bg-slate-900 border-2 ${isAdminUnlocked ? 'border-red-500' : 'border-slate-700'} rounded-3xl overflow-hidden shadow-2xl relative transition-all duration-300 transform scale-100`}>
        
        {/* Nuke effect overlay */}
        {isNuked && (
          <div className="absolute inset-0 bg-red-600/30 z-[1] animate-pulse pointer-events-none flex items-center justify-center">
            <span className="text-4xl font-black text-white italic tracking-wider uppercase animate-bounce">⚠️ WARNING: NUKE COMMENCING ⚠️</span>
          </div>
        )}

        {/* Modal Header */}
        <div className={`px-6 py-4 flex justify-between items-center bg-gradient-to-r ${isAdminUnlocked ? 'from-red-600 to-rose-600 text-white' : 'from-slate-800 to-slate-900 text-gray-300'} border-b border-white/10`}>
          <div className="flex items-center gap-3">
            <Shield className="w-6 h-6 animate-pulse" />
            <div>
              <h2 className="font-sans font-black italic text-lg uppercase tracking-wider">🛠️ Client Admin Abuse Dashboard</h2>
              <p className="text-[10px] opacity-75 font-mono">ROBLOX-INSPIRED CONSOLE DEVELOPER MODE</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1 px-3 border border-white/20 rounded-full hover:bg-white/10 active:scale-95 transition-all text-xs cursor-pointer font-black"
          >
            <X className="w-4 h-4 inline mr-1" /> CLOSE
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6 max-h-[80vh] overflow-y-auto space-y-6">
          
          {actionSuccessMsg && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="bg-green-500/10 border border-green-500 text-green-400 px-4 py-2 text-center text-xs font-black italic uppercase rounded-xl"
            >
              🚀 {actionSuccessMsg}
            </motion.div>
          )}

          {!isAdminUnlocked ? (
            /* LOCK SCREEN - Prompt code Input */
            <form onSubmit={handleUnlock} className="space-y-6 text-center py-6">
              <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mx-auto border-2 border-red-500 shadow-[0_0_20px_rgba(239,68,68,0.3)] animate-pulse">
                <Terminal className="w-10 h-10 text-red-500" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-black italic tracking-wide uppercase text-white">Enter Dev Authorization Authorization Keys</h3>
                <p className="text-sm text-gray-400 font-bold">This is a protected zone. Type in secret code to unlock the Roblox Admin Abuse console dashboard.</p>
              </div>

              <div className="max-w-md mx-auto space-y-4">
                <input 
                  type="text"
                  value={adminCode}
                  onChange={(e) => setAdminCode(e.target.value)}
                  placeholder="AUTHORIZATION CODE DIRECT"
                  className="w-full bg-black/50 hover:bg-black/80 border-2 border-red-500/40 rounded-2xl px-6 py-4 font-mono text-center tracking-[0.2em] text-white focus:border-red-500 outline-none transition-all text-sm md:text-base placeholder-gray-500 uppercase font-black"
                  autoFocus
                />
                
                {authError && (
                  <p className="text-red-400 font-extrabold text-xs uppercase animate-bounce">❌ {authError}</p>
                )}

                <button 
                  type="submit"
                  className="w-full bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-black italic py-4 rounded-xl uppercase tracking-widest shadow-[0_5px_0_rgb(185,28,28)] active:translate-y-1 active:shadow-none transition-all cursor-pointer border-0"
                >
                  🚀 Connect Dev Interface
                </button>
              </div>
            </form>
          ) : (
            /* CONTROL BOARD SCREEN */
            <div className="space-y-6 text-left">
              
              {/* Header Info */}
              <div className="bg-red-500/5 px-4 py-3.5 border border-red-500/20 rounded-2xl flex flex-wrap justify-between items-center gap-2">
                <div className="text-xs font-bold text-gray-400">
                  <span className="text-red-400 font-black">STRIKING_MODE: ACTIVE ⚠️</span> | Authenticated Admin
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={lockAdminConsole}
                    className="bg-slate-800 hover:bg-slate-700 border border-white/10 text-rose-400 text-[10px] font-black uppercase px-3 py-1 rounded-lg cursor-pointer"
                  >
                    Lock Console
                  </button>
                  <button 
                    onClick={resetAllModifiers}
                    className="bg-red-950/40 hover:bg-red-900/60 border border-red-500/30 text-red-300 text-[10px] font-black uppercase px-3 py-1 rounded-lg cursor-pointer"
                  >
                    🚨 Stop All Buffs
                  </button>
                </div>
              </div>

              {/* SECTION A: BROADCAST SYSTEM MESSAGES TO PLAYERS SCREEN */}
              <div className="space-y-2 border border-slate-700/50 p-4 rounded-2xl bg-black/20">
                <h3 className="font-black italic text-sm tracking-widest text-slate-300 uppercase flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-rose-500" />
                  Roblox Server Broadcaster (Type Messages appearing on player screen)
                </h3>
                <p className="text-[11px] text-gray-400 font-bold">Write a notification message that immediately slides onto the top of every online player screen.</p>
                
                <div className="flex flex-col gap-3 mt-3">
                  <input
                    type="text"
                    value={broadCastText}
                    onChange={(e) => setBroadCastText(e.target.value)}
                    placeholder="E.g., Special Event has initialized Double Luck Multipliers!"
                    className="w-full bg-slate-850 border border-slate-700 rounded-xl px-4 py-3 font-bold text-xs focus:border-red-500 focus:outline-none"
                  />
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    {/* Prefix and Colors */}
                    <div className="flex items-center gap-4 text-xs">
                      <div className="space-y-1">
                        <label className="text-[10px] font-extrabold text-gray-500 block">SENDER LABEL</label>
                        <input 
                          type="text" 
                          value={customBroadcastSender}
                          onChange={(e) => setCustomBroadcastSender(e.target.value)}
                          className="bg-slate-800 text-white rounded px-2.5 py-1 text-xs font-mono font-bold w-[120px] focus:outline-none border border-slate-700"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-extrabold text-gray-500 block">ALERT COLOR</label>
                        <select 
                          value={broadcastColor}
                          onChange={(e) => setBroadcastColor(e.target.value)}
                          className="bg-slate-800 text-white rounded px-2 py-1 text-xs font-bold w-[100px] focus:outline-none border border-slate-700"
                        >
                          <option value="#f43f5e">Rose Red</option>
                          <option value="#eab308">Gold Yellow</option>
                          <option value="#3b82f6">Brawl Blue</option>
                          <option value="#a855f7">Epic Purple</option>
                          <option value="#22c55e">Lucky Green</option>
                        </select>
                      </div>
                    </div>
                    {/* Submit */}
                    <button
                      onClick={() => triggerBroadcast(broadCastText)}
                      disabled={!broadCastText.trim()}
                      className="bg-rose-500 hover:bg-rose-400 disabled:opacity-50 text-black font-black text-xs px-5 py-2.5 rounded-xl uppercase tracking-widest cursor-pointer active:scale-95 transition-all"
                    >
                      📢 Broadcast Message
                    </button>
                  </div>
                </div>
              </div>

              {/* SECTION B: MANGO POINTS RAIN EFFECT */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3 border border-slate-700/50 p-4 rounded-2xl bg-black/20 flex flex-col justify-between">
                  <div>
                    <h3 className="font-black italic text-sm tracking-widest text-slate-300 uppercase flex items-center gap-2">
                      <CloudRain className="w-4 h-4 text-yellow-500" />
                      Mango Points Rain
                    </h3>
                    <p className="text-[11px] text-gray-400 font-bold mt-1">Make 🥭 raw mangoes tumble from the heavens. Players click them to gain +5 Mango points instantly.</p>
                  </div>

                  <div className="space-y-3 mt-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-extrabold text-gray-500 block">RAIN TIMER ACTIVATED</label>
                      <div className="flex gap-2">
                        {[15, 30, 60, 120].map((sec) => (
                          <button
                            key={sec}
                            onClick={() => setRainDurationChoice(sec)}
                            className={`flex-1 text-xs font-black py-1.5 rounded-lg border transition-all ${
                              rainDurationChoice === sec 
                                ? 'bg-yellow-500 text-black border-yellow-500 shadow-[0_0_10px_rgba(234,179,8,0.2)]' 
                                : 'bg-slate-800 text-gray-400 border-slate-700'
                            }`}
                          >
                            {sec}s
                          </button>
                        ))}
                      </div>
                    </div>

                    <button
                      onClick={startMangoPointsRain}
                      className="w-full bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400 text-black font-black italic text-xs py-3 rounded-xl uppercase tracking-widest cursor-pointer shadow-[0_3px_0_rgb(202,138,4)] active:translate-y-0.5 active:shadow-none transition-all h-[40px]"
                    >
                      🥭 Launch Mango Rain!
                    </button>
                  </div>
                </div>

                {/* CRATE LUCK MULTIPLIERS */}
                <div className="space-y-3 border border-slate-700/50 p-4 rounded-2xl bg-black/20 flex flex-col justify-between">
                  <div>
                    <h3 className="font-black italic text-sm tracking-widest text-slate-300 uppercase flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-purple-400" />
                      Crate Luck Multipliers
                    </h3>
                    <p className="text-[11px] text-gray-400 font-bold mt-1">Enhance probabilities of winning New Characters, Skins, & Prestige tokens from unboxing crates.</p>
                  </div>

                  <div className="space-y-3 mt-3">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-extrabold text-gray-500 block">MULTIPLIER AMOUNT</label>
                        <select
                          value={luckMultiplier}
                          onChange={(e) => setLuckMultiplier(Number(e.target.value))}
                          className="w-full bg-slate-800 text-white rounded-lg px-2 py-1.5 text-xs font-bold border border-slate-700 focus:outline-none"
                        >
                          <option value="2">2X Luck</option>
                          <option value="5">5X Luck</option>
                          <option value="10">10X Luck</option>
                          <option value="100">100X LUCK (MEME)</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-extrabold text-gray-500 block">DURATION (TIME)</label>
                        <select
                          value={luckDuration}
                          onChange={(e) => setLuckDuration(Number(e.target.value))}
                          className="w-full bg-slate-800 text-white rounded-lg px-2 py-1.5 text-xs font-bold border border-slate-700 focus:outline-none"
                        >
                          <option value="30">30 Seconds</option>
                          <option value="60">1 Minute</option>
                          <option value="300">5 Minutes</option>
                          <option value="600">10 Minutes</option>
                        </select>
                      </div>
                    </div>

                    <button
                      onClick={applyLuckBoost}
                      className="w-full bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-400 hover:to-indigo-400 text-white font-black italic text-xs py-3 rounded-xl uppercase tracking-widest cursor-pointer shadow-[0_3px_0_rgb(109,40,217)] active:translate-y-0.5 active:shadow-none transition-all h-[40px]"
                    >
                      🔮 Inject Luck Boost
                    </button>
                  </div>
                </div>
              </div>

              {/* COIN MULTIPLIERS */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3 border border-slate-700/50 p-4 rounded-2xl bg-black/20 flex flex-col justify-between">
                  <div>
                    <h3 className="font-black italic text-sm tracking-widest text-slate-300 uppercase flex items-center gap-2">
                      <Coins className="w-4 h-4 text-emerald-400" />
                      Coin Multipliers
                    </h3>
                    <p className="text-[11px] text-gray-400 font-bold mt-1">Multiply matches reward payouts. Boost end-of-game coins collection by actual multipliers.</p>
                  </div>

                  <div className="space-y-3 mt-3">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-extrabold text-gray-500 block">COIN MULT AMOUNT</label>
                        <select
                          value={coinMultiplier}
                          onChange={(e) => setCoinMultiplier(Number(e.target.value))}
                          className="w-full bg-slate-800 text-white rounded-lg px-2 py-1.5 text-xs font-bold border border-slate-700 focus:outline-none"
                        >
                          <option value="2">2X Coins</option>
                          <option value="3">3X Coins</option>
                          <option value="5">5X Coins</option>
                          <option value="10">10X Coins</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-extrabold text-gray-500 block">TIMER RUNTIME</label>
                        <select
                          value={coinDuration}
                          onChange={(e) => setCoinDuration(Number(e.target.value))}
                          className="w-full bg-slate-800 text-white rounded-lg px-2 py-1.5 text-xs font-bold border border-slate-700 focus:outline-none"
                        >
                          <option value="30">30 Seconds</option>
                          <option value="60">1 Minute</option>
                          <option value="300">5 Minutes</option>
                        </select>
                      </div>
                    </div>

                    <button
                      onClick={applyCoinBoost}
                      className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white font-black italic text-xs py-3 rounded-xl uppercase tracking-widest cursor-pointer shadow-[0_3px_0_rgb(4,120,87)] active:translate-y-0.5 active:shadow-none transition-all h-[40px]"
                    >
                      🪙 Lock Coin Boost
                    </button>
                  </div>
                </div>

                {/* SECTION E: NOSTALGIC ROBLOX COMMANDS */}
                <div className="space-y-3 border border-slate-700/50 p-4 rounded-2xl bg-black/20 flex flex-col justify-between">
                  <div>
                    <h3 className="font-black italic text-sm tracking-widest text-slate-300 uppercase flex items-center gap-2">
                      <Skull className="w-4 h-4 text-red-500" />
                      Meme Roblox Admin Commands
                    </h3>
                    <p className="text-[11px] text-gray-400 font-bold mt-1">Execute classic, fun simulated developer actions on the server with real online sound alarms.</p>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mt-3">
                    <button
                      onClick={triggerSlapAll}
                      className="bg-amber-600/30 hover:bg-amber-600/50 text-amber-300 text-xs font-black py-2.5 rounded-xl border border-amber-500/20 uppercase tracking-wider cursor-pointer active:scale-95 transition-all text-center flex items-center justify-center gap-1.5"
                    >
                      👋 Slap Everyone
                    </button>
                    <button
                      onClick={triggerNuke}
                      disabled={isNuked}
                      className="bg-red-600/30 hover:bg-red-600/50 text-red-300 disabled:opacity-50 text-xs font-black py-2.5 rounded-xl border border-red-500/20 uppercase tracking-wider cursor-pointer active:scale-95 transition-all text-center flex items-center justify-center gap-1.5"
                    >
                      ☢️ Nuke Server
                    </button>
                    <button
                      onClick={() => triggerBroadcast('🛡️ [ADMIN ABUSE]: GOD MODE GENERATED (100% HEALTH BOOSTER)')}
                      className="bg-blue-600/30 hover:bg-blue-600/50 text-blue-300 text-xs font-black py-2.5 rounded-xl border border-blue-500/20 uppercase tracking-wider cursor-pointer active:scale-95 transition-all text-center flex items-center justify-center gap-1.5"
                    >
                      ❤️ Heal Server
                    </button>
                    <button
                      onClick={() => triggerBroadcast('🌈 [ATMOSPHERE ERROR]: UNLEASHING RAINBOW MODE ATMOSPHERE!')}
                      className="bg-pink-600/30 hover:bg-pink-600/50 text-pink-300 text-xs font-black py-2.5 rounded-xl border border-pink-500/20 uppercase tracking-wider cursor-pointer active:scale-95 transition-all text-center flex items-center justify-center gap-1.5"
                    >
                      ✨ Spasm Theme
                    </button>
                  </div>
                </div>
              </div>

              {/* ACTIVE STATUS TIMERS BOARD */}
              <div className="p-4 bg-slate-800/40 rounded-2xl border border-slate-700/50 space-y-2">
                <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">Active Admin Multiplier Timers</h4>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="p-2.5 bg-black/20 rounded-xl space-y-1">
                    <span className="text-[10px] text-gray-400 font-extrabold uppercase">🔮 Luck Multiplier</span>
                    <div className="font-extrabold text-sm text-purple-300">
                      {userData.adminLuckExpr && userData.adminLuckExpr > currentTime ? (
                        <span>{userData.adminLuckMultiplier}X ({Math.ceil((userData.adminLuckExpr - currentTime) / 1000)}s left)</span>
                      ) : (
                        <span className="text-gray-500 italic">None</span>
                      )}
                    </div>
                  </div>
                  <div className="p-2.5 bg-black/20 rounded-xl space-y-1">
                    <span className="text-[10px] text-gray-400 font-extrabold uppercase">🪙 Coin Multiplier</span>
                    <div className="font-extrabold text-sm text-emerald-300">
                      {userData.adminCoinExpr && userData.adminCoinExpr > currentTime ? (
                        <span>{userData.adminCoinMultiplier}X ({Math.ceil((userData.adminCoinExpr - currentTime) / 1000)}s left)</span>
                      ) : (
                        <span className="text-gray-500 italic">None</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>
      </div>
    </div>
  );
}
