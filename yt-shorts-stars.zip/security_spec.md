# Security Specification for Meme Brawlers Multiplayer

## Data Invariants
- A player can only exist within a valid room.
- A player can only update their own `PlayerState` document.
- Only the host of a room can update the `Room` document (status, scores, timeLeft).
- Players cannot modify other players' states.
- Timestamps and server state must be consistent.

## The "Dirty Dozen" Payloads
1. **Identity Spoofing**: Attempt to update another player's coordinates.
2. **Room Hijack**: Non-host attempts to change room status to 'starting'.
3. **Score Manipulation**: Non-host attempts to increment team score.
4. **ID Poisoning**: Creating a room with a 2MB string as ID.
5. **Shadow Fields**: Adding `isAdmin: true` to a player profile.
6. **State Shortcutting**: Moving room from 'lobby' directly to 'finished'.
7. **Resource Poisoning**: Sending 1MB string in `name` field.
8. **Unauthorized Join**: Writing to `players` collection of a room that doesn't exist.
9. **Spamming Events**: Writing `lastShot` every millisecond (throttling is hard in rules but size/type checks help).
10. **Immortality**: Setting health to `999999`.
11. **Time Travel**: Updating `lastUpdated` to a future timestamp.
12. **Teleportation**: (Hard to prevent without server-side physics, but can check max speed roughly).

## Test Runner (Conceptual)
See `firestore.rules.test.ts` (would use firebase-testing-library if environment allowed, here I'll enforce via rules logic).

## Security Rules Implementation Detail
- `isValidId(id)`
- `isValidRoom(data)`
- `isValidPlayer(data)`
- `isHost(roomId)`
